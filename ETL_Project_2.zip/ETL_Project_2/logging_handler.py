def show_error_message(error_string_prefix,error_string_suffix ):
    error_message = error_string_prefix + "=" + error_string_suffix
    print(error_message)